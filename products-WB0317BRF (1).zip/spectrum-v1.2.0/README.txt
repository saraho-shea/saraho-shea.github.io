------------------
Spectrum Support
------------------

Thank you for choosing Spectrum! If you run into any issues with using this template,
please don't hesitate to send us a message on our profile at WrapBootstrap.
https://wrapbootstrap.com/user/StartBootstrap

Since you've purchased this template, you will receive dedicated email support as part of the purchase.
We will try our best to answer your emails as soon as we can!

------------------
Spectrum Docs
------------------

The complete theme documentation is available in the /docs/index.html file.
Please access that file for complete usage instructions! If you have a question, feel free to email us!